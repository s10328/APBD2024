using System.ComponentModel.DataAnnotations;

namespace BlazorAppWebAssembly.Models;

public class Student
{
    [Required(ErrorMessage = "ID is required")]
    public int IdStudent { get; set; }
    
    [Required(ErrorMessage = "First Name is required")]
    public string FirstName { get; set; }
    
    [Required(ErrorMessage = "Last Name is required")]
    public string LastName { get; set; }
}