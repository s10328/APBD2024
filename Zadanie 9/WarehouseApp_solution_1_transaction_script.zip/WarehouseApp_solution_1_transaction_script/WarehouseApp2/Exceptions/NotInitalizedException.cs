namespace WarehouseApp2.Exceptions;

public class NotInitalizedException() : Exception("Unit of work is not initialized");