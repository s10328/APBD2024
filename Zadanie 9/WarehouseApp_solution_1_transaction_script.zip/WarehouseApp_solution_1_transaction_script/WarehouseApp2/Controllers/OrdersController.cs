using Microsoft.AspNetCore.Mvc;
using WarehouseApp2.Exceptions;
using WarehouseApp2.RequestModels;
using WarehouseApp2.Services;

namespace WarehouseApp2.Controllers;

[ApiController]
[Route("orders")]
public class OrdersController : ControllerBase
{
    private readonly IOrderService _orderService;
    
    public OrdersController(IOrderService orderService)
    {
        _orderService = orderService;
    }
    
    [HttpPost("{idOrder}")]
    public async Task<IActionResult> FulfillOrder(int idOrder, FulfillOrderCommand command, CancellationToken cancellationToken)
    {
        if (idOrder != command.IdOrder)
        {
            return BadRequest("URL does not match the order");
        }
        
        return Ok(await _orderService.FulfillOrderAsync(command, cancellationToken));
    }
}