namespace WarehouseApp2.Models;

public class Warehouse
{
    public int IdWarehouse { get; set; }
    public string Name { get; set; }
    public string Address { get; set; }
}