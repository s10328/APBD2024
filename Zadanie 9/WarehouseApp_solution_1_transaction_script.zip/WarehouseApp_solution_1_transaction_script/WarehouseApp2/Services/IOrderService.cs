using WarehouseApp2.RequestModels;

namespace WarehouseApp2.Services;

public interface IOrderService
{
    Task<int> FulfillOrderAsync(FulfillOrderCommand command, CancellationToken cancellationToken);
}