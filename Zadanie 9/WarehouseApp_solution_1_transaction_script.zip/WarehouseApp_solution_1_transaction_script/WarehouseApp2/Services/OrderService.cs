using WarehouseApp2.Exceptions;
using WarehouseApp2.Models;
using WarehouseApp2.Repositories;
using WarehouseApp2.RequestModels;

namespace WarehouseApp2.Services;

public class OrderService : IOrderService
{
    private readonly IProductRepository _productRepository;
    private readonly IWarehouseRepository _warehouseRepository;
    private readonly IOrderRepository _orderRepository;
    private readonly IUnitOfWork _unitOfWork;
    
    public OrderService(IProductRepository productRepository, IWarehouseRepository warehouseRepository, IOrderRepository orderRepository,
        IUnitOfWork unitOfWork)
    {
        _productRepository = productRepository;
        _warehouseRepository = warehouseRepository;
        _orderRepository = orderRepository;
        _unitOfWork = unitOfWork;
    }

    public async Task<int> FulfillOrderAsync(FulfillOrderCommand command, CancellationToken cancellationToken)
    {
        await _unitOfWork.InitializeAsync(cancellationToken);
        
        EnsureAmountIsAboveZero(command);
        
        Product? product = await _productRepository.GetProductAsync(command.IdProduct, cancellationToken);
        EnsureProductExists(command, product);

        Warehouse? warehouse = await _warehouseRepository.GetWarehouseAsync(command.IdWarehouse, cancellationToken);
        EnsureWarehouseExists(command, warehouse);

        Order? order = await _orderRepository.GetOrderAsync(command.IdOrder, cancellationToken);
        EnsureOrderExists(command, order);
        EnsureAmountIsValid(command, order!);
        EnsureCreatedAtIsValid(command, order!);
        EnsureOrderNotFulfilled(order!);
        
        var newLineOrderItem = new Product_Warehouse
        {
            IdProduct = product!.IdProduct,
            IdWarehouse = warehouse!.IdWarehouse,
            IdOrder=order.IdOrder,
            Amount = command.Amount,
            Price = command.Amount*product.Price,
            CreatedAt = command.CreatedAt
        };
        order.OrderLineItems.Add(newLineOrderItem);

        FulfillOrderIfPossible(order);

        int idLineOrderItem=await _orderRepository.CreateNewOrderLineItemAsync(newLineOrderItem, cancellationToken);
        
        _ = await _orderRepository.UpdateOrderAsync(order, cancellationToken)!;
        
        await _unitOfWork.CommitAsync(cancellationToken);
        
        return idLineOrderItem;
    }

    private static void FulfillOrderIfPossible(Order order)
    {
        int missingAmount = GetUnfulfilledAmount(order);
        if (missingAmount == 0)
        {
            order!.FulfilledAt=DateTime.Now;
        }
    }

    private static void EnsureAmountIsAboveZero(FulfillOrderCommand command)
    {
        if (command.Amount <= 0)
        {
            throw new DomainException($"Amount must be above zero. Current value {command.Amount} is incorrect.");
        }
    }

    private static void EnsureProductExists(FulfillOrderCommand command, Product? product)
    {
        if (product == null)
        {
            throw new DomainException($"Product with id {command.IdProduct} does not exist");
        }
    }

    private static void EnsureWarehouseExists(FulfillOrderCommand command, Warehouse? warehouse)
    {
        if (warehouse == null)
        {
            throw new DomainException($"Warehouse with id {command.IdWarehouse} does not exist");
        }
    }

    private static void EnsureOrderExists(FulfillOrderCommand command, Order? order)
    {
        if (order == null)
        {
            throw new DomainException($"Order with idProduct={command.IdProduct} and idWarehouse={command.IdWarehouse} was not found");
        }
    }

    private static void EnsureAmountIsValid(FulfillOrderCommand command, Order order)
    {
        if (command.Amount>order.Amount)
        {
            throw new DomainException($"Command's amount is higher than order's amount");
        }

        int missingAmount = GetUnfulfilledAmount(order);
        if (missingAmount == 0)
        {
            throw new DomainException($"Order {order.IdOrder} seems to be already fulfilled");
        }

        if (command.Amount > missingAmount)
        {
            throw new DomainException($"We cannot order more than the order's missing amount");
        }
    }

    private static int GetFulfilledAmount(Order order)
    {
        return order.OrderLineItems.Sum(ol => ol.Amount);
    }
    
    private static int GetUnfulfilledAmount(Order order)
    {
        return order.Amount-order.OrderLineItems.Sum(ol => ol.Amount);
    }

    private static void EnsureCreatedAtIsValid(FulfillOrderCommand command, Order order)
    {
        if (command.CreatedAt < order.CreatedAt)
        {
            throw new DomainException($"Created at in the request does not match the order's data");
        }
    }

    private static void EnsureOrderNotFulfilled(Order order)
    {
        if (order.FulfilledAt != null)
        {
            throw new DomainException($"Order with id={order.IdOrder} was already fulfilled");
        }
    }
}