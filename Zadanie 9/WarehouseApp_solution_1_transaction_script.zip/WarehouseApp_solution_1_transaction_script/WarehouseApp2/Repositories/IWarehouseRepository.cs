using WarehouseApp2.Models;

namespace WarehouseApp2.Repositories;

public interface IWarehouseRepository : IRepository
{
    Task<Warehouse?> GetWarehouseAsync(int idWarehouse, CancellationToken cancellationToken);
}