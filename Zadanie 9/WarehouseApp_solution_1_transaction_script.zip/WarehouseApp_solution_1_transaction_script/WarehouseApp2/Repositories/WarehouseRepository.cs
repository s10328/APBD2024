using Microsoft.Data.SqlClient;
using WarehouseApp2.Models;

namespace WarehouseApp2.Repositories;

public class WarehouseRepository : IWarehouseRepository
{
    private readonly IUnitOfWork _unitOfWork;

    public WarehouseRepository(IUnitOfWork unitOfWork)
    {
        _unitOfWork = unitOfWork;
    }
    
    public async Task<Warehouse?> GetWarehouseAsync(int idWarehouse, CancellationToken cancellationToken)
    {
        await using SqlCommand com = _unitOfWork.CreateCommand();
        com.CommandText = "SELECT * FROM Warehouse WHERE IdWarehouse=@IdWarehouse";
        com.Parameters.AddWithValue("IdWarehouse", idWarehouse);

        await using var dr = await com.ExecuteReaderAsync(cancellationToken);

        Warehouse? warehouse = null;
        if (await dr.ReadAsync(cancellationToken))
        {
            warehouse = new Warehouse
            {
                IdWarehouse = (int)dr["IdWarehouse"],
                Name = dr["Name"].ToString(),
                Address = dr["Address"].ToString()
            };
        }

        return warehouse;
    }
}