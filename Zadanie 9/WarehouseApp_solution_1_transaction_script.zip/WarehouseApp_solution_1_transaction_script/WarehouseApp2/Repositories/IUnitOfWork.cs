using Microsoft.Data.SqlClient;

namespace WarehouseApp2.Repositories;

public interface IUnitOfWork : IDisposable, IAsyncDisposable
{
    Task InitializeAsync(CancellationToken cancellationToken);
    Task CommitAsync(CancellationToken cancellationToken);
    SqlCommand CreateCommand();
}