using Microsoft.Data.SqlClient;
using WarehouseApp2.Models;

namespace WarehouseApp2.Repositories;

public class ProductRepository : IProductRepository
{
    private readonly IUnitOfWork _unitOfWork;

    public ProductRepository(IUnitOfWork unitOfWork)
    {
        _unitOfWork = unitOfWork;
    }
    
    public async Task<Product?> GetProductAsync(int idProduct, CancellationToken cancellationToken)
    {
        await using SqlCommand com = _unitOfWork.CreateCommand();
        com.CommandText = "SELECT * FROM Product WHERE IdProduct=@IdProduct";
        com.Parameters.AddWithValue("@IdProduct", idProduct);

        await using var dr = await com.ExecuteReaderAsync(cancellationToken);

        Product? product = null;
        if (await dr.ReadAsync(cancellationToken))
        {
            product = new Product
            {
                IdProduct = (int)dr["IdProduct"],
                Name = dr["Name"].ToString(),
                Description = dr["Description"].ToString(),
                Price = (decimal)dr["Price"]
            };
        }

        return product;
    }
}