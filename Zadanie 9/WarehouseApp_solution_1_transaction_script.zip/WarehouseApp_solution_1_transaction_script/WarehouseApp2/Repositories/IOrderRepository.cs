using WarehouseApp2.Models;

namespace WarehouseApp2.Repositories;

public interface IOrderRepository : IRepository
{
    Task<Order?> GetOrderAsync(int idOrder, CancellationToken cancellationToken);
    Task<int>? UpdateOrderAsync(Order order, CancellationToken cancellationToken);
    Task<int> CreateNewOrderLineItemAsync(Product_Warehouse lineOrderItem, CancellationToken cancellationToken);
}