using Microsoft.Data.SqlClient;
using WarehouseApp2.Models;

namespace WarehouseApp2.Repositories;

public class OrderRepository : IOrderRepository
{
    private IUnitOfWork _unitOfWork;

    public OrderRepository(IUnitOfWork unitOfWork)
    {
        _unitOfWork = unitOfWork;
    }
    
    public async Task<Order?> GetOrderAsync(int idOrder, CancellationToken cancellationToken)
    {
        await using SqlCommand com = _unitOfWork.CreateCommand();
        com.CommandText = @"SELECT o.IdOrder, o.IdProduct, o.Amount as OrderAmount, o.CreatedAt as OrderCreatedAt, o.FulfilledAt, 
                            pw.IdProductWarehouse, pw.IdWarehouse, pw.Amount as OrderLineItemAmount, pw.Price, pw.CreatedAt as OrderLineItemCreatedAt
                            FROM dbo.[Order] o 
                            LEFT JOIN Product_Warehouse pw ON pw.IdOrder=o.IdOrder
                            WHERE o.IdOrder=@IdOrder";
        com.Parameters.AddWithValue("IdOrder", idOrder);

        await using var dr = await com.ExecuteReaderAsync(cancellationToken);

        Order? order = null;
        while (await dr.ReadAsync(cancellationToken))
        {
            order ??= new Order
            {
                IdOrder = (int)dr["IdOrder"],
                IdProduct = (int)dr["IdProduct"],
                Amount = (int)dr["OrderAmount"],
                CreatedAt = (DateTime)dr["OrderCreatedAt"],
                FulfilledAt = dr["FulfilledAt"]==DBNull.Value ? null : (DateTime)dr["FulfilledAt"]
            };

            if (dr["IdProductWarehouse"] == DBNull.Value) continue;
            
            var orderLineItem = new Product_Warehouse
            {
                IdProductWarehouse = (int)dr["IdProductWarehouse"],
                IdProduct = (int)dr["IdProduct"],
                IdWarehouse = (int)dr["IdWarehouse"],
                Amount = (int)dr["OrderLineItemAmount"],
                Price = (decimal)dr["Price"],
                CreatedAt = (DateTime) dr["OrderLineItemCreatedAt"]
            };
            order.OrderLineItems.Add(orderLineItem);
        }
        
        return order;
    }

    public async Task<int>? UpdateOrderAsync(Order order, CancellationToken cancellationToken)
    {
        await using SqlCommand com = _unitOfWork.CreateCommand();
        //TODO We can add the rest of the fields
        com.CommandText = @"UPDATE dbo.[Order] SET
                            Amount=@Amount,
                            FulfilledAt=@FulfilledAt
                            WHERE IdOrder=@IdOrder";
        com.Parameters.AddWithValue("Amount", order.Amount);
        com.Parameters.AddWithValue("FulfilledAt", order.FulfilledAt==null ? DBNull.Value : order.FulfilledAt);
        com.Parameters.AddWithValue("IdOrder", order.IdOrder);
        
        await com.ExecuteNonQueryAsync(cancellationToken);
        
        return order.IdOrder;
    }

    public async Task<int> CreateNewOrderLineItemAsync(Product_Warehouse lineOrderItem, CancellationToken cancellationToken)
    {
        await using SqlCommand com = _unitOfWork.CreateCommand();
        com.CommandText = @"INSERT INTO Product_Warehouse(IdWarehouse, IdProduct, IdOrder, Amount, Price, CreatedAt)
                            VALUES(@IdWarehouse, @IdProduct, @IdOrder, @Amount, @Price, @CreatedAt);
                            SELECT SCOPE_IDENTITY();";
        com.Parameters.AddWithValue("IdWarehouse", lineOrderItem.IdWarehouse);
        com.Parameters.AddWithValue("IdProduct", lineOrderItem.IdProduct);
        com.Parameters.AddWithValue("IdOrder", lineOrderItem.IdOrder);
        com.Parameters.AddWithValue("Amount", lineOrderItem.Amount);
        com.Parameters.AddWithValue("Price", lineOrderItem.Price);
        com.Parameters.AddWithValue("CreatedAt", lineOrderItem.CreatedAt);
        
        await com.ExecuteScalarAsync(cancellationToken);
        
        return lineOrderItem.IdProductWarehouse;
    }
}