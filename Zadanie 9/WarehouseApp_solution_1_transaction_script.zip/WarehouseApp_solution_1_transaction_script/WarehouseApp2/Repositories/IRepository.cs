namespace WarehouseApp2.Repositories;

public interface IRepository
{
    
}