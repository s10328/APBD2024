using WarehouseApp2.Models;

namespace WarehouseApp2.Repositories;

public interface IProductRepository : IRepository
{
    Task<Product?> GetProductAsync(int idProduct, CancellationToken cancellationToken);
}