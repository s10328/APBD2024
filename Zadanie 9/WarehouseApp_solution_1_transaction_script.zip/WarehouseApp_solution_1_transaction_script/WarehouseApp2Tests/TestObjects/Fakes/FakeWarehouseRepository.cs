using WarehouseApp2.Models;
using WarehouseApp2.Repositories;

namespace WarehouseApp2Tests.TestObjects.Fakes;

public class FakeWarehouseRepository : IWarehouseRepository
{
    private ICollection<Warehouse> warehouses;

    public FakeWarehouseRepository()
    {
        warehouses = new List<Warehouse>
        {
            new Warehouse { IdWarehouse = 11, Name = "Central Warehouse", Address = "1234 Main St, Anytown" },
            new Warehouse { IdWarehouse = 12, Name = "East Warehouse", Address = "5678 East St, Eastville" },
            new Warehouse { IdWarehouse = 13, Name = "West Warehouse", Address = "91011 West St, Westville" }
        };
    }

    public Task<Warehouse?> GetWarehouseAsync(int idWarehouse, CancellationToken cancellationToken)
    {
        return Task.FromResult(warehouses.FirstOrDefault(w => w.IdWarehouse == idWarehouse));
    }
}