using WarehouseApp2.Models;
using WarehouseApp2.Repositories;

namespace WarehouseApp2Tests.TestObjects.Fakes;

public class FakeOrderRepository : IOrderRepository
{
    private ICollection<Order> orders;

    public FakeOrderRepository()
    {
        orders = new List<Order>
        {
            new Order {
                IdOrder = 301,
                IdProduct = 503,
                Amount = 10,
                CreatedAt = DateTime.Now.AddDays(-10),
                FulfilledAt = DateTime.Now.AddDays(-5),
                OrderLineItems = {
                    new Product_Warehouse {
                        IdProductWarehouse = 3011,
                        IdWarehouse = 12,
                        IdProduct = 501,
                        IdOrder = 101,
                        Amount = 10,
                        Price = 150.00m,
                        CreatedAt = DateTime.Now.AddDays(-10)
                    }
                }
            },
            new Order {
                IdOrder = 302,
                IdProduct = 501,
                Amount = 10,
                CreatedAt = DateTime.Now.AddDays(-10),
                FulfilledAt = null,
                OrderLineItems = {
                    new Product_Warehouse {
                        IdProductWarehouse = 3011,
                        IdWarehouse = 12,
                        IdProduct = 501,
                        IdOrder = 101,
                        Amount = 5,
                        Price = 150.00m,
                        CreatedAt = DateTime.Now.AddDays(-10)
                    }
                }
            },
            new Order {
                IdOrder = 201,
                IdProduct = 501,
                Amount = 10,
                CreatedAt = DateTime.Now.AddDays(-10),
                FulfilledAt = null,
                OrderLineItems = {
                    new Product_Warehouse {
                        IdProductWarehouse = 1,
                        IdWarehouse = 11,
                        IdProduct = 501,
                        IdOrder = 101,
                        Amount = 10,
                        Price = 150.00m,
                        CreatedAt = DateTime.Now.AddDays(-10)
                    }
                }
            },
            new Order {
                IdOrder = 101,
                IdProduct = 501,
                Amount = 3,
                CreatedAt = DateTime.Now.AddDays(-10),
                FulfilledAt = DateTime.Now.AddDays(-5),
                OrderLineItems = {
                    new Product_Warehouse {
                        IdProductWarehouse = 1,
                        IdWarehouse = 11,
                        IdProduct = 501,
                        IdOrder = 101,
                        Amount = 3,
                        Price = 150.00m,
                        CreatedAt = DateTime.Now.AddDays(-10)
                    }
                }
            },
            new Order {
                IdOrder = 102,
                IdProduct = 502,
                Amount = 5,
                CreatedAt = DateTime.Now.AddDays(-8),
                FulfilledAt = null,
                OrderLineItems = {
                    new Product_Warehouse {
                        IdProductWarehouse = 2,
                        IdWarehouse = 12,
                        IdProduct = 502,
                        IdOrder = 102,
                        Amount = 2,
                        Price = 120.00m,
                        CreatedAt = DateTime.Now.AddDays(-8)
                    },
                    new Product_Warehouse {
                        IdProductWarehouse = 3,
                        IdWarehouse = 12,
                        IdProduct = 502,
                        IdOrder = 102,
                        Amount = 3,
                        Price = 180.00m,
                        CreatedAt = DateTime.Now.AddDays(-8)
                    }
                }
            },
            new Order {
                IdOrder = 103,
                IdProduct = 503,
                Amount = 1,
                CreatedAt = DateTime.Now.AddDays(-15),
                FulfilledAt = DateTime.Now.AddDays(-12),
                OrderLineItems = {
                    new Product_Warehouse {
                        IdProductWarehouse = 4,
                        IdWarehouse = 13,
                        IdProduct = 503,
                        IdOrder = 103,
                        Amount = 1,
                        Price = 90.00m,
                        CreatedAt = DateTime.Now.AddDays(-15)
                    }
                }
            }
        };
    }
    
    public Task<Order?> GetOrderAsync(int idOrder, CancellationToken cancellationToken)
    {
        return Task.FromResult(orders.FirstOrDefault(o => o.IdOrder==idOrder));
    }

    public Task<int>? UpdateOrderAsync(Order order, CancellationToken cancellationToken)
    {
        var o =  orders.FirstOrDefault(o => o.IdOrder==order.IdOrder);

        if (o == null)
        {
            throw new ArgumentException($"Order with id={order.IdOrder} does not exist");
        }
        
        o.IdProduct = order.IdProduct;
        o.CreatedAt = order.CreatedAt;
        o.FulfilledAt = order.FulfilledAt;

        return Task.FromResult(o.IdOrder);
    }

    public Task<int> CreateNewOrderLineItemAsync(Product_Warehouse lineOrderItem, CancellationToken cancellationToken)
    {
        var o =  orders.FirstOrDefault(o => o.IdOrder==lineOrderItem.IdOrder);
        
        if (o == null)
        {
            throw new ArgumentException($"Order with id={lineOrderItem.IdOrder} does not exist");
        }

        lineOrderItem.IdProductWarehouse = o.OrderLineItems.Max(ol => ol.IdProductWarehouse) + 1;
        o.OrderLineItems.Add(lineOrderItem);
        
        return Task.FromResult(lineOrderItem.IdProductWarehouse);
    }
}