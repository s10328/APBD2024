using WarehouseApp2.Models;
using WarehouseApp2.Repositories;

namespace WarehouseApp2Tests.TestObjects.Fakes;

public class FakeProductRepository : IProductRepository
{
    private ICollection<Product> products;

    public FakeProductRepository()
    {
        products = new List<Product>
        {
            new Product { IdProduct = 501, Name = "Laptop", Description = "High-performance laptop", Price = 1200.00m },
            new Product { IdProduct = 502, Name = "Smartphone", Description = "Latest model smartphone", Price = 800.00m },
            new Product { IdProduct = 503, Name = "Tablet", Description = "Portable and powerful tablet", Price = 600.00m }
        };
    }

    public Task<Product?> GetProductAsync(int idProduct, CancellationToken cancellationToken)
    {
        return Task.FromResult(products.FirstOrDefault(p => p.IdProduct == idProduct));
    }
}