using Microsoft.Data.SqlClient;
using WarehouseApp2.Repositories;

namespace WarehouseApp2Tests.TestObjects.Fakes;

public class FakeUnitOfWork : IUnitOfWork
{
    public void Dispose()
    {
        
    }

    public ValueTask DisposeAsync()
    {
        return ValueTask.CompletedTask;
    }

    public Task InitializeAsync(CancellationToken cancellationToken)
    {
        return Task.CompletedTask;
    }

    public Task CommitAsync(CancellationToken cancellationToken)
    {
        return Task.CompletedTask;
    }

    public SqlCommand CreateCommand()
    {
        return new SqlCommand();
    }
}