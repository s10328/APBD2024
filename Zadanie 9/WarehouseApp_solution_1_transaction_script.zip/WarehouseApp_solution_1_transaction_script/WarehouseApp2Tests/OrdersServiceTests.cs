using Shouldly;
using WarehouseApp2.Exceptions;
using WarehouseApp2.RequestModels;
using WarehouseApp2.Services;
using WarehouseApp2Tests.TestObjects.Fakes;

namespace WarehouseApp2Tests;

public class OrdersServiceTests
{
    private readonly IOrderService _orderService;
    
    public OrdersServiceTests()
    {
        _orderService = new OrderService(new FakeProductRepository(),
            new FakeWarehouseRepository(), new FakeOrderRepository(), new FakeUnitOfWork());
    }
    
    [Fact]
    public async Task Should_ThrowException_WhenAmountIsLessThanZero()
    {
        //Arrange
        var command = new FulfillOrderCommand
        {
            IdOrder = 1,
            IdWarehouse = 11,
            IdProduct = 501,
            Amount = -10
        };
        
        //Act and Assert
        await Should.ThrowAsync<DomainException>(_orderService.FulfillOrderAsync(command, CancellationToken.None));
    }
    
    [Fact]
    public async Task Should_ThrowException_WhenProductDoesNotExist()
    {
        //Arrange
        var command = new FulfillOrderCommand
        {
            IdOrder = 1,
            IdWarehouse = 11,
            IdProduct = 1200,
            Amount = 10
        };
        
        //Act and Assert
        await Should.ThrowAsync<DomainException>(_orderService.FulfillOrderAsync(command, CancellationToken.None));
    }
    
    [Fact]
    public async Task Should_ThrowException_WhenOrderDoesNotExist()
    {
        //Arrange
        var command = new FulfillOrderCommand
        {
            IdOrder = 1,
            IdWarehouse = 120,
            IdProduct = 501,
            Amount = 10
        };
        
        //Act and Assert
        await Should.ThrowAsync<DomainException>(_orderService.FulfillOrderAsync(command, CancellationToken.None));
    }
    
    [Fact]
    public async Task Should_ThrowException_WhenOrderAmountAlreadyFulfilled()
    {
        //Arrange
        var command = new FulfillOrderCommand
        {
            IdOrder = 1,
            IdWarehouse = 12,
            IdProduct = 503,
            Amount = 5
        };
        
        //Act and Assert
        await Should.ThrowAsync<DomainException>(_orderService.FulfillOrderAsync(command, CancellationToken.None));
    }
    
    [Fact]
    public async Task Should_ThrowException_WhenCommandHasHigherAmountThanOrder()
    {
        //Arrange
        var command = new FulfillOrderCommand
        {
            IdOrder = 1,
            IdWarehouse = 12,
            IdProduct = 501,
            Amount = 20
        };
        
        //Act and Assert
        await Should.ThrowAsync<DomainException>(_orderService.FulfillOrderAsync(command, CancellationToken.None));
    }
    
    [Fact]
    public async Task Should_ReturnId_WhenNewOrderLineItemCreated()
    {
        //Arrange
        var command = new FulfillOrderCommand
        {
            IdOrder = 302,
            IdWarehouse = 12,
            IdProduct = 501,
            Amount = 5,
            CreatedAt = DateTime.Now
        };
        
        //Act and Assert
        var result = await _orderService.FulfillOrderAsync(command, CancellationToken.None);
        
        //Assert
        result.ShouldBeGreaterThan(0);
    }
}