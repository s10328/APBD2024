﻿namespace GakkoHorizontalSlice.Model
{
    public class RefreshTokenRequest
    {
        public string RefreshToken { get; set; }
    }
}
